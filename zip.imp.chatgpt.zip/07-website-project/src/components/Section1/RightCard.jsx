import React from 'react'
import RightCardContent from './RightCardContent'

const RightCard = () => {
  return (
    <div className='h-full shrink-0 overflow-hidden relative w-80  rounded-4xl'>
      <img className="h-full w-full object-cover" src="https://i.pinimg.com/736x/ef/97/25/ef972507d073f998e8091814528e86d1.jpg" alt="" />
      <RightCardContent/>

    </div>
  )
}

export default RightCard