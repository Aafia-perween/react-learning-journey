import React from 'react'

const Section2 = () => {
  return (
    <div className='h-screen w-full bg-gray-900'>
      
    </div>
  )
}

export default Section2